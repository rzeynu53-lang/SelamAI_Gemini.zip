package com.selamai.assistant.ui.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selamai.assistant.ui.theme.NotoSansEthiopic

private sealed class MarkdownSegment {
    data class ParagraphBlock(val text: String) : MarkdownSegment()
    data class CodeBlock(val language: String, val code: String) : MarkdownSegment()
}

@Composable
fun MarkdownText(
    markdown: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val segments = remember(markdown) { parseMarkdownSegments(markdown) }
    val codeBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)

    SelectionContainer {
        Column(modifier = modifier) {
            segments.forEachIndexed { index, segment ->
                when (segment) {
                    is MarkdownSegment.CodeBlock -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = codeBackground,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (segment.language.isNotBlank()) {
                                    Text(
                                        text = segment.language,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                Text(
                                    text = segment.code,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                )
                            }
                        }
                    }

                    is MarkdownSegment.ParagraphBlock -> {
                        val annotated = remember(segment.text, codeBackground) {
                            buildMarkdownAnnotatedString(segment.text, codeBackground)
                        }
                        Text(
                            text = annotated,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontFamily = NotoSansEthiopic,
                                color = textColor
                            )
                        )
                    }
                }
                if (index < segments.lastIndex) {
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

private fun parseMarkdownSegments(raw: String): List<MarkdownSegment> {
    val result = mutableListOf<MarkdownSegment>()
    val regex = Regex("```([a-zA-Z0-9_-]*)\\n?([\\s\\S]*?)```")
    var lastIndex = 0

    regex.findAll(raw).forEach { match ->
        if (match.range.first > lastIndex) {
            val before = raw.substring(lastIndex, match.range.first).trim('\n')
            if (before.isNotEmpty()) {
                result.add(MarkdownSegment.ParagraphBlock(before))
            }
        }
        val lang = match.groupValues[1].trim()
        val codeContent = match.groupValues[2].trimEnd()
        result.add(MarkdownSegment.CodeBlock(lang, codeContent))
        lastIndex = match.range.last + 1
    }

    if (lastIndex < raw.length) {
        val remaining = raw.substring(lastIndex).trim('\n')
        if (remaining.isNotEmpty()) {
            result.add(MarkdownSegment.ParagraphBlock(remaining))
        }
    }

    if (result.isEmpty() && raw.isNotEmpty()) {
        result.add(MarkdownSegment.ParagraphBlock(raw))
    }
    return result
}

private fun buildMarkdownAnnotatedString(
    text: String,
    inlineCodeBg: Color
): AnnotatedString = buildAnnotatedString {
    val lines = text.lines()
    lines.forEachIndexed { lineIdx, rawLine ->
        val trimmed = rawLine.trimStart()
        when {
            trimmed.startsWith("### ") -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp)) {
                    appendInlineMarkdown(trimmed.removePrefix("### "), inlineCodeBg)
                }
            }
            trimmed.startsWith("## ") -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 19.sp)) {
                    appendInlineMarkdown(trimmed.removePrefix("## "), inlineCodeBg)
                }
            }
            trimmed.startsWith("# ") -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 21.sp)) {
                    appendInlineMarkdown(trimmed.removePrefix("# "), inlineCodeBg)
                }
            }
            trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                append("• ")
                appendInlineMarkdown(trimmed.substring(2), inlineCodeBg)
            }
            else -> {
                appendInlineMarkdown(rawLine, inlineCodeBg)
            }
        }
        if (lineIdx < lines.lastIndex) {
            append("\n")
        }
    }
}

private fun AnnotatedString.Builder.appendInlineMarkdown(
    line: String,
    inlineCodeBg: Color
) {
    val tokenRegex = Regex("""(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)""")
    var cursor = 0
    tokenRegex.findAll(line).forEach { match ->
        if (match.range.first > cursor) {
            append(line.substring(cursor, match.range.first))
        }
        val token = match.value
        when {
            token.startsWith("**") && token.endsWith("**") && token.length > 4 -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    append(token.substring(2, token.length - 2))
                }
            }
            token.startsWith("`") && token.endsWith("`") && token.length > 2 -> {
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = inlineCodeBg,
                        fontSize = 14.sp
                    )
                ) {
                    append(" " + token.substring(1, token.length - 1) + " ")
                }
            }
            token.startsWith("*") && token.endsWith("*") && token.length > 2 -> {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    append(token.substring(1, token.length - 1))
                }
            }
            else -> append(token)
        }
        cursor = match.range.last + 1
    }
    if (cursor < line.length) {
        append(line.substring(cursor))
    }
}
