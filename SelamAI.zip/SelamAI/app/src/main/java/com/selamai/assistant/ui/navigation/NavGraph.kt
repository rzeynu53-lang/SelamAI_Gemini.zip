package com.selamai.assistant.ui.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.selamai.assistant.ui.chat.ChatScreen
import com.selamai.assistant.ui.chat.ChatViewModel
import com.selamai.assistant.ui.memory.MemoryScreen
import com.selamai.assistant.ui.memory.MemoryViewModel
import com.selamai.assistant.ui.settings.SettingsScreen
import com.selamai.assistant.ui.settings.SettingsViewModel

object Routes {
    const val CHAT = "chat"
    const val MEMORY = "memory"
    const val SETTINGS = "settings"
}

@Composable
fun SelamNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Routes.CHAT
    ) {
        composable(Routes.CHAT) {
            val chatViewModel: ChatViewModel = hiltViewModel()
            ChatScreen(
                viewModel = chatViewModel,
                onNavigateToMemory = { navController.navigate(Routes.MEMORY) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.MEMORY) {
            val memoryViewModel: MemoryViewModel = hiltViewModel()
            MemoryScreen(
                viewModel = memoryViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            SettingsScreen(
                viewModel = settingsViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
