package com.selamai.assistant.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GeminiGenerateRequest(
    @SerialName("system_instruction")
    val systemInstruction: GeminiSystemInstruction? = null,
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig = GeminiGenerationConfig()
)

@Serializable
data class GeminiSystemInstruction(
    val parts: List<GeminiPart>
)

@Serializable
data class GeminiContent(
    val role: String, // "user" or "model"
    val parts: List<GeminiPart>
)

@Serializable
data class GeminiPart(
    val text: String? = null,
    @SerialName("inline_data")
    val inlineData: GeminiInlineData? = null
) {
    companion object {
        fun textPart(text: String) = GeminiPart(text = text)
        fun imagePart(mimeType: String, base64Data: String) = GeminiPart(
            inlineData = GeminiInlineData(
                mimeType = mimeType,
                data = base64Data
            )
        )
    }
}

@Serializable
data class GeminiInlineData(
    @SerialName("mime_type")
    val mimeType: String,
    val data: String
)

@Serializable
data class GeminiGenerationConfig(
    val maxOutputTokens: Int = 4096
)
