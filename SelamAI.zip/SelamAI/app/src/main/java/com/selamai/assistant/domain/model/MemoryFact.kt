package com.selamai.assistant.domain.model

data class MemoryFact(
    val id: Long = 0L,
    val category: String,
    val content: String,
    val updatedAt: Long = System.currentTimeMillis()
)
