package com.selamai.assistant.ui.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.selamai.assistant.R
import java.io.File

@Composable
fun ChatInputBar(
    inputText: String,
    onInputTextChange: (String) -> Unit,
    attachedImagePath: String?,
    onRemoveAttachedImage: () -> Unit,
    onPickFromGalleryClick: () -> Unit,
    onTakeCameraPhotoClick: () -> Unit,
    isListeningVoice: Boolean,
    voiceLocale: String,
    onToggleVoiceLocale: () -> Unit,
    onVoiceInputClick: () -> Unit,
    isStreaming: Boolean,
    onSendClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showImageMenu by remember { mutableStateOf(false) }

    Surface(
        tonalElevation = 3.dp,
        shadowElevation = 4.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            // Image attachment preview bar
            if (!attachedImagePath.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(6.dp)
                ) {
                    AsyncImage(
                        model = File(attachedImagePath),
                        contentDescription = stringResource(R.string.attach_image),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onRemoveAttachedImage,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = stringResource(R.string.remove_image)
                        )
                    }
                }
            }

            // Voice locale selector chip (am-ET / en-US)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                AssistChip(
                    onClick = onToggleVoiceLocale,
                    label = {
                        Text(
                            text = if (voiceLocale == "am-ET") {
                                stringResource(R.string.voice_lang_am)
                            } else {
                                stringResource(R.string.voice_lang_en)
                            },
                            style = MaterialTheme.typography.labelMedium
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                    },
                    modifier = Modifier.height(28.dp)
                )
            }

            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Attach image (Camera or Gallery)
                Box {
                    IconButton(onClick = { showImageMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = stringResource(R.string.attach_image),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    DropdownMenu(
                        expanded = showImageMenu,
                        onDismissRequest = { showImageMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.take_photo)) },
                            leadingIcon = {
                                Icon(Icons.Default.CameraAlt, contentDescription = null)
                            },
                            onClick = {
                                showImageMenu = false
                                onTakeCameraPhotoClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.choose_gallery)) },
                            leadingIcon = {
                                Icon(Icons.Default.Image, contentDescription = null)
                            },
                            onClick = {
                                showImageMenu = false
                                onPickFromGalleryClick()
                            }
                        )
                    }
                }

                // Voice Input Button
                IconButton(onClick = onVoiceInputClick) {
                    Icon(
                        imageVector = if (isListeningVoice) Icons.Default.StopCircle else Icons.Default.Mic,
                        contentDescription = stringResource(R.string.voice_input),
                        tint = if (isListeningVoice) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.primary
                        }
                    )
                }

                // Message Input TextField (Ethiopic & English)
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = {
                        Text(
                            text = stringResource(R.string.type_message_hint),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    maxLines = 5,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                )

                // Send Button
                val canSend = !isStreaming && (inputText.isNotBlank() || !attachedImagePath.isNullOrBlank())
                FilledIconButton(
                    onClick = onSendClick,
                    enabled = canSend,
                    shape = CircleShape,
                    modifier = Modifier.size(46.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.send)
                    )
                }
            }
        }
    }
}
