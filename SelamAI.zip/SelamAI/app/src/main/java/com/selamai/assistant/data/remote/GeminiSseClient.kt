package com.selamai.assistant.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.selamai.assistant.data.remote.dto.GeminiGenerateRequest
import com.selamai.assistant.data.remote.dto.GeminiStreamResponseDto
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

sealed class SseEvent {
    data class TokenDelta(val text: String) : SseEvent()
    data class RateLimitRetry(val attempt: Int, val waitMs: Long) : SseEvent()
    data object Completed : SseEvent()
    data class Error(val errorType: AiErrorType, val message: String) : SseEvent()
}

enum class AiErrorType {
    OFFLINE,
    INVALID_API_KEY,
    RATE_LIMIT,
    API_ERROR,
    NETWORK_ERROR
}

@Singleton
class GeminiSseClient @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val json: Json
) {

    fun streamGenerateContent(
        apiKey: String,
        model: String,
        requestPayload: GeminiGenerateRequest
    ): Flow<SseEvent> = flow {
        if (apiKey.isBlank()) {
            emit(
                SseEvent.Error(
                    AiErrorType.INVALID_API_KEY,
                    "Gemini API key is missing. Please enter your key in Settings."
                )
            )
            return@flow
        }

        if (!isNetworkAvailable()) {
            emit(
                SseEvent.Error(
                    AiErrorType.OFFLINE,
                    "No internet connection. Please check your network and try again."
                )
            )
            return@flow
        }

        val primaryModel = model.trim().ifBlank { DEFAULT_MODEL }
        val candidateModels = linkedSetOf(
            primaryModel,
            "gemini-3.8-flash",
            "gemini-3.8-flash-lite",
            "gemini-3.8-pro"
        ).toList()

        val requestJson = json.encodeToString(requestPayload)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        var finished = false
        var lastErrorType = AiErrorType.API_ERROR
        var lastErrorMessage = "Gemini API error."

        for ((modelIndex, currentModel) in candidateModels.withIndex()) {
            if (finished) break

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$currentModel:streamGenerateContent?alt=sse&key=$apiKey"
            var attempt = 0
            val maxRetriesPerModel = 1

            while (attempt <= maxRetriesPerModel && !finished) {
                val request = Request.Builder()
                    .url(url)
                    .addHeader("content-type", "application/json")
                    .addHeader("accept", "text/event-stream")
                    .post(requestJson.toRequestBody(mediaType))
                    .build()

                var shouldRetrySameModel = false
                var shouldFallbackNextModel = false

                try {
                    okHttpClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            val code = response.code
                            val rawError = response.body?.string().orEmpty()
                            val parsedMessage = parseErrorMessage(rawError, code)
                            lastErrorMessage = parsedMessage

                            when {
                                code == 401 || code == 403 || (code == 400 && rawError.contains("API_KEY", ignoreCase = true)) -> {
                                    emit(SseEvent.Error(AiErrorType.INVALID_API_KEY, parsedMessage))
                                    finished = true
                                }
                                code == 404 -> {
                                    lastErrorType = AiErrorType.API_ERROR
                                    shouldFallbackNextModel = true
                                }
                                code == 429 || code == 503 -> {
                                    lastErrorType = AiErrorType.RATE_LIMIT
                                    if (attempt < maxRetriesPerModel) {
                                        shouldRetrySameModel = true
                                    } else {
                                        shouldFallbackNextModel = true
                                    }
                                }
                                else -> {
                                    lastErrorType = AiErrorType.API_ERROR
                                    emit(SseEvent.Error(AiErrorType.API_ERROR, parsedMessage))
                                    finished = true
                                }
                            }
                        } else {
                            val body = response.body
                            if (body == null) {
                                emit(SseEvent.Error(AiErrorType.API_ERROR, "Empty response stream from Gemini API."))
                                finished = true
                            } else {
                                BufferedReader(
                                    InputStreamReader(body.byteStream(), StandardCharsets.UTF_8)
                                ).use { reader ->
                                    var line: String?
                                    while (reader.readLine().also { line = it } != null) {
                                        val currentLine = line?.trim() ?: continue
                                        if (!currentLine.startsWith("data:")) continue

                                        val dataPayload = currentLine.removePrefix("data:").trim()
                                        if (dataPayload.isEmpty() || dataPayload == "[DONE]") continue

                                        val chunkDto = runCatching {
                                            json.decodeFromString<GeminiStreamResponseDto>(dataPayload)
                                        }.getOrNull() ?: continue

                                        if (chunkDto.error != null) {
                                            val errMsg = chunkDto.error.message ?: "Stream error returned by Gemini."
                                            emit(SseEvent.Error(AiErrorType.API_ERROR, errMsg))
                                            finished = true
                                            break
                                        }

                                        val parts = chunkDto.candidates?.firstOrNull()?.content?.parts
                                        parts?.forEach { part ->
                                            val deltaText = part.text
                                            if (!deltaText.isNullOrEmpty()) {
                                                emit(SseEvent.TokenDelta(deltaText))
                                            }
                                        }
                                    }
                                }
                                if (!finished) {
                                    emit(SseEvent.Completed)
                                    finished = true
                                }
                            }
                        }
                    }
                } catch (e: IOException) {
                    val errorType = if (!isNetworkAvailable()) {
                        AiErrorType.OFFLINE
                    } else {
                        AiErrorType.NETWORK_ERROR
                    }
                    emit(
                        SseEvent.Error(
                            errorType,
                            e.localizedMessage ?: "Network connection interrupted."
                        )
                    )
                    finished = true
                }

                if (shouldRetrySameModel) {
                    attempt++
                    val waitMs = 1500L
                    emit(SseEvent.RateLimitRetry(attempt, waitMs))
                    delay(waitMs)
                } else if (shouldFallbackNextModel) {
                    if (modelIndex < candidateModels.lastIndex) {
                        emit(SseEvent.RateLimitRetry(modelIndex + 1, 800L))
                        delay(800L)
                    }
                    break
                }
            }
        }

        if (!finished) {
            emit(SseEvent.Error(lastErrorType, lastErrorMessage))
        }
    }.flowOn(Dispatchers.IO)

    private fun parseErrorMessage(rawJson: String, statusCode: Int): String {
        val dto = runCatching {
            json.decodeFromString<GeminiStreamResponseDto>(rawJson)
        }.getOrNull()
        val detail = dto?.error?.message
        return if (!detail.isNullOrBlank()) {
            "HTTP $statusCode: $detail"
        } else {
            when (statusCode) {
                400, 401, 403 -> "Invalid Gemini API key (HTTP $statusCode). Please check your key in Settings."
                429, 503 -> "Gemini server is temporarily busy (HTTP $statusCode). Please try again in a moment."
                else -> "Gemini API error (HTTP $statusCode)."
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
    }
}
