package com.selamai.assistant.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.selamai.assistant.data.local.dao.ConversationDao
import com.selamai.assistant.data.local.dao.MemoryFactDao
import com.selamai.assistant.data.local.dao.MessageDao
import com.selamai.assistant.data.local.entity.ConversationEntity
import com.selamai.assistant.data.local.entity.MemoryFactEntity
import com.selamai.assistant.data.local.entity.MessageEntity

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryFactEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryFactDao(): MemoryFactDao

    companion object {
        const val DATABASE_NAME = "selam_ai_db"
    }
}
