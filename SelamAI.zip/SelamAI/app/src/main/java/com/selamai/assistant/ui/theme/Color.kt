package com.selamai.assistant.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Ethiopian Highland Teal & Warm Gold accents)
val PrimaryLight = Color(0xFF0F766E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFCCFBF1)
val OnPrimaryContainerLight = Color(0xFF042F2E)

val SecondaryLight = Color(0xFFB45309)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFEF3C7)
val OnSecondaryContainerLight = Color(0xFF451A03)

val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF334155)

// Dark Theme Colors
val PrimaryDark = Color(0xFF2DD4BF)
val OnPrimaryDark = Color(0xFF042F2E)
val PrimaryContainerDark = Color(0xFF115E59)
val OnPrimaryContainerDark = Color(0xFFCCFBF1)

val SecondaryDark = Color(0xFFFBBF24)
val OnSecondaryDark = Color(0xFF451A03)
val SecondaryContainerDark = Color(0xFF78350F)
val OnSecondaryContainerDark = Color(0xFFFEF3C7)

val BackgroundDark = Color(0xFF0B1120)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF334155)
val OnSurfaceVariantDark = Color(0xFFCBD5E1)
