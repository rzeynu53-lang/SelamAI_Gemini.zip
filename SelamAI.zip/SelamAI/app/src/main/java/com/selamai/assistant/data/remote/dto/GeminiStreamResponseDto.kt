package com.selamai.assistant.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class GeminiStreamResponseDto(
    val candidates: List<GeminiCandidateDto>? = null,
    val error: GeminiErrorDetailDto? = null
)

@Serializable
data class GeminiCandidateDto(
    val content: GeminiCandidateContentDto? = null,
    val finishReason: String? = null
)

@Serializable
data class GeminiCandidateContentDto(
    val parts: List<GeminiResponsePartDto>? = null,
    val role: String? = null
)

@Serializable
data class GeminiResponsePartDto(
    val text: String? = null
)

@Serializable
data class GeminiErrorDetailDto(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)
