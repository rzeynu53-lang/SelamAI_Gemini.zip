package com.selamai.assistant.domain.model

import com.selamai.assistant.data.remote.AiErrorType

sealed class StreamStatus {
    data object Idle : StreamStatus()
    data class Streaming(val partialText: String) : StreamStatus()
    data class RetryingRateLimit(val attempt: Int, val waitMs: Long) : StreamStatus()
    data class Error(val errorType: AiErrorType, val message: String) : StreamStatus()
    data object Completed : StreamStatus()
}
