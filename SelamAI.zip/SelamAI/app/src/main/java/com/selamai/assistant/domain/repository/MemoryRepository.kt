package com.selamai.assistant.domain.repository

import com.selamai.assistant.domain.model.MemoryFact
import kotlinx.coroutines.flow.Flow

interface MemoryRepository {
    fun observeMemoryFacts(): Flow<List<MemoryFact>>
    suspend fun getAllMemoryFacts(): List<MemoryFact>
    suspend fun addMemoryFact(category: String, content: String)
    suspend fun updateMemoryFact(fact: MemoryFact)
    suspend fun deleteMemoryFact(id: Long)
}
