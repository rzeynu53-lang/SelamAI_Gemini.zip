package com.selamai.assistant.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageRole
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ExportHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * Exports a conversation to a UTF-8 encoded .txt file (preserving Amharic / Ethiopic script)
     * and launches the Android Share sheet so the user can save or send it anywhere.
     */
    fun exportConversationToTextFile(
        conversation: Conversation,
        messages: List<Message>
    ): File {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val exportText = buildString {
            appendLine("==========================================")
            appendLine("ሰላም AI (SelamAI) - የውይይት ቅጂ / Chat Export")
            appendLine("ርዕስ / Title: ${conversation.title}")
            appendLine("ቀን / Date: ${dateFormat.format(Date())}")
            appendLine("==========================================")
            appendLine()

            messages.forEach { msg ->
                val senderLabel = when (msg.role) {
                    MessageRole.USER -> "እርስዎ / You"
                    MessageRole.ASSISTANT -> "ሰላም AI / Claude"
                }
                val timeStr = dateFormat.format(Date(msg.timestamp))
                appendLine("[$timeStr] $senderLabel:")
                if (!msg.imagePath.isNullOrBlank()) {
                    appendLine("[ምስል ተያይዟል / Attached Image]")
                }
                appendLine(msg.content)
                appendLine("------------------------------------------")
            }
        }

        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeTitle = conversation.title
            .replace(Regex("""[^\p{L}\p{N}_-]+"""), "_")
            .take(30)
            .ifBlank { "conversation" }

        val exportFile = File(exportDir, "SelamAI_${safeTitle}_${System.currentTimeMillis()}.txt")
        exportFile.writeText(exportText, StandardCharsets.UTF_8)
        return exportFile
    }

    fun shareExportedFile(file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain; charset=utf-8"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.nameWithoutExtension)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, file.name).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
