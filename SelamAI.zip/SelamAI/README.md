# ሰላም AI (SelamAI) — Amharic & English Personal AI Assistant (Android)

**SelamAI** (`com.selamai.assistant`) በአማርኛ እና በእንግሊዝኛ የሚሰራ፣ ስለ እርስዎ እውነታዎችን (ግቦች፣ ምርጫዎች፣ ልማዶች) በስልክዎ ላይ የሚያስታውስ የግል AI ረዳት የአንድሮይድ መተግበሪያ ነው።

---

## 1. የቴክኖሎጂ መዋቅር (Tech Stack)
- **ቋንቋ እና UI**: Kotlin 2.0.21 + Jetpack Compose (Material 3)
- **አርክቴክቸር**: Clean Architecture (`data` / `domain` / `ui`) + MVVM + Hilt Dependency Injection
- **ዳታቤዝ (On-Device)**: Room SQLite (`conversations`, `messages`, `memory_facts`)
- **AI ሞዴል እና Streaming**: Anthropic Claude API (`POST https://api.anthropic.com/v1/messages`, ሞዴል፦ `claude-sonnet-5-5`) በOkHttp SSE ቃል በቃል (Token-by-Token) ምላሽ የሚሰጥ
- **ደህንነት**: የAPI ቁልፍ በኮድ ውስጥ አይጻፍም (Never Hardcoded)፤ ተጠቃሚው በቅንብሮች (Settings) ውስጥ ሲያስገባ በ`EncryptedSharedPreferences` (`AES256_GCM`) ተመስጥሮ ይቀመጣል
- **SDK**: `minSdk = 26` (Android 8.0), `targetSdk = 35` (Android 15)

---

## 2. ዋና ዋና ባህሪያት (Features)
1. **የውይይት ገጽ (Chat Screen)**: የመልእክት ሳጥኖች (Bubbles)፣ Markdown ማሳያ (Bold, Italic, Code Blocks, Headings, Bullets)፣ ወደ ቅንጥብ ሰሌዳ መቅጃ (Copy)፣ እንደገና ማመንጫ (Regenerate) እና Typing/Loading Indicator።
2. **ብዙ ውይይቶች (Multiple Conversations)**: በጎን ማውጫ (Drawer) ውስጥ ውይይቶችን መዘርዘር፣ መፈለግ (Search)፣ ስም መቀየር (Rename) እና ማጥፋት (Delete)።
3. **የግል ማስታወሻ (Memory Screen)**: AIው ስለ እርስዎ የተማራቸውን እውነታዎች (Goal/ግብ፣ Preference/ምርጫ፣ Habit/ልማድ፣ General/አጠቃላይ) ማየት፣ ማስተካከል (Edit)፣ መጨመር እና ማጥፋት። እነዚህ እውነታዎች በሁሉም የClaude ጥያቄዎች ውስጥ እንደ Context ይካተታሉ።
4. **የድምፅ ግብዓት እና ንባብ (Voice Input & Read-Aloud)**: በአንድሮይድ `SpeechRecognizer` በአማርኛ (`am-ET`) እና በእንግሊዝኛ (`en-US`) በድምፅ መጻፍ፤ እንዲሁም ምላሾችን በ`TextToSpeech` በድምፅ ማንበብ።
5. **የምስል አባሪዎች (Image Attachments)**: ከካሜራ ፎቶ በማንሳት ወይም ከጋለሪ በመምረጥ ወደ Base64 ተቀይሮ ለClaude Vision API መላክ።
6. **የጨለማ እና ብሩህ ገጽታ (Dark / Light Theme)**: System Default፣ Light እና Dark ገጽታዎች።
7. **ውይይት ወደ ፋይል መላክ (Export Conversation)**: ውይይቶችን የአማርኛ ፊደላት ሳይበላሹ በUTF-8 `.txt` ፋይል ወደ ውጭ መላክ እና ማጋራት።
8. **ሙሉ የአማርኛ ድጋፍ (Amharic Support)**: የ`Noto Sans Ethiopic` ፎንት (`res/font/noto_sans_ethiopic_regular.ttf` እና `bold.ttf`) እና የአማርኛ (`values-am/strings.xml`) + የእንግሊዝኛ (`values/strings.xml`) የUI ጽሑፎች።

---

## 3. የAPK መገንቢያ ትዕዛዝ (Build Command & Output APK Path)

### ሀ) በኮምፒውተር (Android Studio / Terminal) ለመገንባት
1. ፕሮጀክቱን ይክፈቱ እና JDK 17 መኖሩን ያረጋግጡ።
2. የሚከተለውን ትዕዛዝ ያስኪዱ፦
   ```bash
   ./gradlew assembleDebug
   ```
3. የተገነባው የDebug APK የሚገኝበት ቦታ (Output APK Path)፦
   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```

### ለ) በስልክ ብቻ (GitHub Actions በመጠቀም) APK ለመገንባት
ኮምፒውተር ከሌለዎት በቀጥታ ከስልክዎ ላይ APK ለመገንባት፦
1. በGitHub ላይ አዲስ Repository ይፍጠሩ እና የዚህን ፕሮጀክት ፋይሎች ይጫኑ (Upload)።
2. በፕሮጀክቱ ውስጥ የተካተተው `.github/workflows/android-build.yml` በራሱ ይነሳል (ወይም **Actions -> Build SelamAI Android APK -> Run workflow** ይጫኑ)።
3. ግንባታው ሲጠናቀቅ ከ**Artifacts** ስር `SelamAI-debug-apk` የሚለውን አውርደው በስልክዎ ላይ ይጫኑት።

---

## 4. የRelease APK ፊርማ ቅደም ተከተል (Release Signing Steps)

መተግበሪያውን ለPlay Store ወይም ለደንበኞች በRelease ሁኔታ ለማዘጋጀት፦

### ደረጃ 1፡ Keystore ፋይል መፍጠር
በTerminal ላይ የሚከተለውን ትዕዛዝ በማስኬድ የግል ፊርማ ቁልፍ (`selamai-release-key.jks`) ይፍጠሩ፦
```bash
keytool -genkey -v \
  -keystore selamai-release-key.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias selamai_key
```

### ደረጃ 2፡ በ`app/build.gradle.kts` ውስጥ `signingConfigs` መጨመር
በ`app/build.gradle.kts` ውስጥ ከ`buildTypes` በፊት የሚከተለውን ያክሉ (የይለፍ ቃሎችን በEnvironment Variables ወይም `keystore.properties` ውስጥ ያስቀምጡ)፦
```kotlin
signingConfigs {
    create("release") {
        storeFile = file(System.getenv("KEYSTORE_PATH") ?: "../selamai-release-key.jks")
        storePassword = System.getenv("KEYSTORE_PASSWORD")
        keyAlias = System.getenv("KEY_ALIAS") ?: "selamai_key"
        keyPassword = System.getenv("KEY_PASSWORD")
    }
}

buildTypes {
    release {
        isMinifyEnabled = true
        isShrinkResources = true
        signingConfig = signingConfigs.getByName("release")
        proguardFiles(
            getDefaultProguardFile("proguard-android-optimize.txt"),
            "proguard-rules.pro"
        )
    }
}
```

### ደረጃ 3፡ የተፈረመ Release APK መገንባት
```bash
./gradlew assembleRelease
```
- የተፈረመው የRelease APK የሚገኝበት ቦታ፦
  ```text
  app/build/outputs/apk/release/app-release.apk
  ```
- የፊርማውን ትክክለኛነት ለማረጋገጥ፦
  ```bash
  apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
  ```

---

## 5. የአማርኛ ፊደላት ትክክለኛነት ማረጋገጫ (Amharic Rendering Verification)
- **በመልእክት ሳጥኖች (Bubbles)**፡ `NotoSansEthiopic` በ`SelamTypography` እና በ`MarkdownText` ውስጥ በቀጥታ ስለተሰጠ የአማርኛ ፊደላት በሁሉም የአንድሮይድ ስልኮች (Android 8.0+) ላይ ሳይቆራረጡ ይታያሉ።
- **በመጻፊያ ሳጥን (Input)**፡ `OutlinedTextField` ከGe'ez ኪቦርዶች (Gboard Amharic, FynGeez) እና ከ`SpeechRecognizer` (`am-ET`) የሚመጡ የአማርኛ ጽሑፎችን በUTF-8 ይቀበላል።
- **በፋይል ኤክስፖርት (Exports)**፡ `ExportHelper` ፋይሉን በ`StandardCharsets.UTF_8` ስለሚጽፈው ወደ `.txt` ሲላክ የአማርኛ ፊደላት በፍጹም አይበላሹም።
